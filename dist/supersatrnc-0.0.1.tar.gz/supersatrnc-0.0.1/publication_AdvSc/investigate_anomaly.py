from supersatrnc import *;
from pylab import plt;
import style as st;
import os;

fig,axs = plt.subplots(nrows=2,figsize=st.figsize())
corr = LiquidRoundJet(CB.liq,32,3,1,0.1)

sp = SimulationParameters(corr,22);

film1 = Film(sp,[DMF,MAPI],2, [1], 1.18)

dyns = AntiSolventDynamics(film1,0.05,antiSolvent=CB);
dyns.computeSolution();
dyns.plotFilmThicknessCompositionAndSupersaturation(axs);


fig,axs = plt.subplots(nrows=2,figsize=st.figsize())
corr = LiquidRoundJet(CB.liq,64,3,1,0.1)

sp = SimulationParameters(corr,22);

film1 = Film(sp,[DMF,MAPI],2, [1], 1.18)

dyns = AntiSolventDynamics(film1,0.05,antiSolvent=CB);
dyns.computeSolution();
dyns.plotFilmThicknessCompositionAndSupersaturation(axs);


fig,axs = plt.subplots(nrows=2,figsize=st.figsize())
corr = LiquidRoundJet(CB.liq,128,3,1,0.1)

sp = SimulationParameters(corr,22);

film1 = Film(sp,[DMF,MAPI],2, [1], 1.18)

dyns = AntiSolventDynamics(film1,0.05,antiSolvent=CB);
dyns.computeSolution();
dyns.plotFilmThicknessCompositionAndSupersaturation(axs);

plt.show()